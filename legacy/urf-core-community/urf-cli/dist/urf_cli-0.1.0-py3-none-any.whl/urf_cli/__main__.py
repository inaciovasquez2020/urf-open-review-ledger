import argparse, json
from pathlib import Path
import jsonschema

def repo_root() -> Path:
    here = Path(__file__).resolve()
    for p in [here, *here.parents]:
        if (p / "pyproject.toml").exists():
            return p
    return Path.cwd().resolve()

def cmd_verify(args):
    root = repo_root()
    cert_path = (root / args.cert).resolve()
    schema_path = (root / args.schema).resolve()

    cert = json.loads(cert_path.read_text())
    schema = json.loads(schema_path.read_text())

    jsonschema.validate(cert, schema)
    print("VALID")

def main():
    p = argparse.ArgumentParser(prog="urf")
    sub = p.add_subparsers(dest="cmd", required=True)

    v = sub.add_parser("verify")
    v.add_argument("cert")
    v.add_argument(
        "--schema",
        default="standards/URF-SG/schema/urf-sg-v1.0.schema.json"
    )
    v.set_defaults(func=cmd_verify)

    args = p.parse_args()
    args.func(args)

if __name__ == "__main__":
    main()

